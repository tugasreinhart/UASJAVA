package programUtama;

public class SharedVariable {
	public static String nama;
	public static String adminName;
	
}
